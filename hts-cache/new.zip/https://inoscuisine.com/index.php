<!DOCTYPE html>
<html lang="en-US">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>inos cuisine | by Chef Sonny Djoko Wibisono</title>
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <link rel="pingback" href="https://inoscuisine.com/xmlrpc.php">
    <meta name="viewport" content="width=device-width; initial-scale=1.0;">
    <link rel="icon" type="image/png" href="https://inos.aksisoft.com/wp-content/uploads/2015/05/logo-01-01.png">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootswatch/3.1.1/united/bootstrap.min.css">
    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.5.2/jquery.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.5/jquery-ui.min.js"></script>
    <script src="https://inoscuisine.com/js/jquery.easing.1.3.js"></script>
    <script src="https://inoscuisine.com/js/raphael-min.js"></script>
    <style type="text/css">
      @font-face{
          font-family:'quicksand';
          src:url("fonts/quicksand.eot");
          src:url("fonts/quicksand.eot?#iefix") format("embedded-opentype"),url("fonts/quicksand.woff") format("woff"),url("fonts/quicksand.ttf") format("truetype"),url("fonts/quicksand.svg#svgFontName") format("svg")
      }
      @font-face{
          font-family:'quicksand regular';
          src:url("fonts/quicksand-regular.eot");
          src:url("fonts/quicksand-regular.eot?#iefix") format("embedded-opentype"),url("fonts/quicksand-regular.woff") format("woff"),url("fonts/quicksand-regular.ttf") format("truetype"),url("fonts/quicksand-regular.svg#svgFontName") format("svg")
      }
      @font-face{
          font-family:'eras light';src:url("fonts/eras.ttf") format("truetype");
          font-weight:normal;
          font-style:normal
      }
      @font-face{
          font-family:'fontello';
          src:url("fonts/fontello.eot?14587781");
          src:url("fonts/fontello.eot?14587781#iefix") format("embedded-opentype"),url("fonts/fontello.woff?14587781") format("woff"),url("fonts/fontello.ttf?14587781") format("truetype"),url("fonts/fontello.svg?14587781#fontello") format("svg");
          font-weight:normal;
          font-style:normal
      }
      .layer{
          width: 900px; margin-left: auto;
          margin-right: auto;
      }
      .gambar-utama{
          margin: auto; position: absolute;
          top: 0; left: 0; bottom: 0; right: 0;
          cursor: pointer;
      }
      .gambar-satu{
          display: none;
          position: absolute; top: -420px;
          margin: auto; left: 0; bottom: 0; right: 0;
      }
      .gambar-dua{
          display: none;
          position: absolute; top: 0px;
          margin: auto; left: -450px; bottom: 0; right: 0;
      }
      .gambar-tiga{
          display: none;
          position: absolute; top: 0px;
          margin: auto; left: 450px; bottom: 0; right: 0;
      }
      .gambar-empat{
          display: none;
          position: absolute; top: 420px;
          margin: auto; left: 0; bottom: 0; right: 0;
      }
      html {
          height: 100%;
      }
      body {
          min-height: 100%;
      }
      body{
          background: url('http://inos.aksisoft.com/wp-content/uploads/2015/05/tumblr_mjc8gxPaaw1s773u2o2_r3_1280-1.jpg') no-repeat fixed center;
      }
      #navWrap {
          height: 40px;
      }
      #nav {
          float:right;
          position:relative;
          left:-50%;
          text-align:left;
          padding: 3px;
          background: #FCFCFC;
      }
      #nav ul {
          position:relative;
          left:50%;
          margin: 0;
          padding: 0;    
      }
      #nav li {
          float: left;
          padding: 5px 8px;
          margin: 0 10px 0 0;
          list-style-type: none;
      }
      #nav li > a {
          color: #333;
          font-family:'quicksand regular', verdana, Arial, sans-serif;
          display: inline-block;
          position: relative;
          padding-bottom: 2px;
          text-decoration: none;
      }
      #nav li > a:after {
          content: '';
          display: block;
          height: 1px;
          width: 0;
          background: transparent;
          transition: width .5s ease, background-color .5s ease;
      }
      #nav li > a:hover:after {
          width: 100%;
          background: #A06D20;
      }
      #wrap {
          margin: 10px auto;
          background: #FCFCFC;
          padding: 10px;
          width: 700px;
      }
      #headers {
          width: 100%;
          position: fixed;
          bottom: 0;
          background: #FCFCFC;
          color: #333;
      }
      @media only screen and (max-width:480px) {
          .layer{width: 100%}
          .gambar-satu{
              height: 100px; width: auto;
          }
          .gambar-dua{
              height: 100px; width: auto;
          }
          .gambar-tiga{
              height: 100px; width: auto;
          }
          .gambar-empat{
              height: 100px; width: auto;
          }
      }
    </style>
  </head>
  <div class="container layer">
    <a href="https://inoscuisine.com/products-page/cookie/">
      <img class="gambar-satu" src="http://inos.aksisoft.com/wp-content/uploads/2015/05/inos-dessert-02-e1432831663327.png" >
    </a>
    <a href="https://inoscuisine.com/products-page/cookie/">
      <img class="gambar-dua" src="http://inos.aksisoft.com/wp-content/uploads/2015/05/Home-front-05-e1432831964518.png" >
    </a>
    <a href="https://inoscuisine.com/products-page/cookie/">
      <img class="gambar-tiga" src="http://inos.aksisoft.com/wp-content/uploads/2015/05/Home-front-04-e1432831946119.png" >
    </a>
    <a href="https://inoscuisine.com/products-page/cookie/">
      <img class="gambar-empat" src="http://inos.aksisoft.com/wp-content/uploads/2015/05/Home-front-03-e1432831924131.png" >
    </a>
    <img class="gambar-utama" src="http://inos.aksisoft.com/wp-content/uploads/2015/05/logo-01.png" >
  </div>
  <div id="headers">
    <div id="navWrap">
      <div id="nav">
        <ul>
            <li><a href="https://inoscuisine.com/home/" class="smoothScroll">Home</a></li><li><a href="https://inoscuisine.com/contact-us/" class="smoothScroll">Contact Us</a></li><li><a href="https://inoscuisine.com/about/" class="smoothScroll">About Us</a></li>        </ul>
        <br class="clearLeft" />
      </div>
    </div>
  </div>
  <div class="handle-sudah" style="display:none;"></div>
  <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
  <script>
      $(document).ready(function () {
          var deviceheight = document.documentElement.clientHeight;
          console.log(deviceheight);
          $(".gambar-utama").hover(function () {
              // $("body").css("height", "600px");
              // $(".layer").css("margin-top", "100px");
          });
          $.browser.chrome = /chrom(e|ium)/.test(navigator.userAgent.toLowerCase());
          var isMobile = false; //initiate as false
// device detection
          if (window.screen.availWidth < 600) {
              isMobile = true;
          }
          // if ($.browser.chrome) {
          if (isMobile) {
              $(".gambar-utama").click(function () {
                  $val_sudah = $(".handle-sudah").html();
                  if ($val_sudah == "") {
                      jeda_space = deviceheight - 150;
                      $(".gambar-utama").hide();
                      $(".gambar-satu").css('top', (0 - jeda_space));
                      // $(".gambar-satu").show();
                      $(".gambar-dua").css('left', 0).css('top', ((0 - jeda_space) + 250));
                      // $(".gambar-dua").show();
                      $(".gambar-tiga").css('left', 0).css('top', ((0 - jeda_space) + 250 + 250));
                      // $(".gambar-tiga").show();
                      $(".gambar-empat").css('left', 0).css('top', ((0 - jeda_space) + 250 + 250 + 250));
                      $(".gambar-satu").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      $(".gambar-dua").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      $(".gambar-tiga").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      $(".gambar-empat").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      // $(".gambar-empat").show();
                      // $(".gambar-tiga").show();
                      // $(".gambar-empat").show();
                      // $(".handle-sudah").text("sudaah mobile");
                  }
              });
          } else {
              $(".gambar-utama").hover(function () {
                  $val_sudah = $(".handle-sudah").html();
                  if ($val_sudah == "") {
                      $(".gambar-satu").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      $(".gambar-dua").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      $(".gambar-tiga").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      $(".gambar-empat").show('scale', {
                          duration: 1000,
                          easing: 'easeInOutElastic',
                      });
                      $(".handle-sudah").text("sudah");
                  }
              });
          }
      });
  </script>
</body>
</html>